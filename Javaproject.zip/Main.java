package quex;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        PatientQueue emergencyQueue = new PatientQueue(5);
        TreatmentStack treatmentStack = new TreatmentStack();

        // This variable will store the first patient
        Patient firstPatient = null;

        System.out.println("===== Hospital Emergency Management System =====");

        // Add 5 patients
        for (int i = 1; i <= 5; i++) {

            System.out.println("\nEnter details for Patient " + i);

            System.out.print("Patient ID: ");
            int id = input.nextInt();
            input.nextLine();

            System.out.print("Patient Name: ");
            String name = input.nextLine();

            System.out.print("Patient Age: ");
            int age = input.nextInt();
            input.nextLine();

            System.out.print("Emergency Condition: ");
            String condition = input.nextLine();

            Patient patient = new Patient(id, name, age, condition);

            // Save first patient
            if (i == 1) {
                firstPatient = patient;
            }

            // Add patient to queue
            emergencyQueue.enqueue(patient);
        }

        // =====================================
        // PATIENT VISIT HISTORY
        // =====================================

        System.out.println("\n===== Patient Visit History =====");

        // Add Visit 1
        firstPatient.visitHistory.addVisit(
                101,
                "2026-08-01",
                "Dr. Silva",
                "Fracture",
                "Pain medication"
        );

        // Add Visit 2
        firstPatient.visitHistory.addVisit(
                102,
                "2026-08-15",
                "Dr. Perera",
                "Fever",
                "Medicine"
        );

        // Add Visit 3
        firstPatient.visitHistory.addVisit(
                103,
                "2026-08-30",
                "Dr. Fernando",
                "Check-up",
                "Rest and follow-up"
        );

        // Display visits
        System.out.println("\n===== All Visit History =====");
        firstPatient.visitHistory.displayVisits();

        // Search visit
        System.out.println("\n===== Search Visit =====");
        firstPatient.visitHistory.searchVisit(102);

        // Remove visit
        System.out.println("\n===== Remove Visit =====");
        firstPatient.visitHistory.removeVisit(102);

        // Display after removal
        System.out.println("\n===== Visit History After Removal =====");
        firstPatient.visitHistory.displayVisits();


        // =====================================
        // DISPLAY QUEUE
        // =====================================

        System.out.println("\n===== Waiting Queue =====");
        emergencyQueue.displayQueue();


        // =====================================
        // DEQUEUE
        // =====================================

        System.out.println("\n===== Treatment =====");
        emergencyQueue.dequeue();


        // =====================================
        // TREATMENT STACK
        // =====================================

        treatmentStack.push("Patient 1 - Emergency treatment completed");
        treatmentStack.push("Patient 2 - X-Ray completed");
        treatmentStack.push("Patient 3 - Surgery completed");

        System.out.println("\n===== Treatment History =====");
        treatmentStack.display();


        // POP
        System.out.println("\n===== POP Treatment =====");
        treatmentStack.pop();


        // DISPLAY AFTER POP
        System.out.println("\n===== Treatment History After POP =====");
        treatmentStack.display();


        // =====================================
        // REMAINING QUEUE
        // =====================================

        System.out.println("\n===== Remaining Waiting Queue =====");
        emergencyQueue.displayQueue();

        input.close();
    }
}