package quex;

public class VisitHistory {

    Visit head;

    // Add a new visit
    public void addVisit(int visitID, String visitDate,
                         String doctorName, String diagnosis,
                         String treatment) {

        Visit newVisit = new Visit(
                visitID, visitDate, doctorName,
                diagnosis, treatment
        );

        if (head == null) {
            head = newVisit;
        } else {

            Visit current = head;

            while (current.next != null) {
                current = current.next;
            }

            current.next = newVisit;
        }

        System.out.println("Visit added successfully.");
    }

    // Remove a visit using Visit ID
    public void removeVisit(int visitID) {

        if (head == null) {
            System.out.println("No visit history found.");
            return;
        }

        // If first visit is the one to remove
        if (head.visitID == visitID) {

            head = head.next;

            System.out.println("Visit removed successfully.");
            return;
        }

        Visit current = head;

        while (current.next != null) {

            if (current.next.visitID == visitID) {

                current.next = current.next.next;

                System.out.println("Visit removed successfully.");
                return;
            }

            current = current.next;
        }

        System.out.println("Visit not found.");
    }

    // Search for a visit using Visit ID
    public void searchVisit(int visitID) {

        if (head == null) {
            System.out.println("No visit history found.");
            return;
        }

        Visit current = head;

        while (current != null) {

            if (current.visitID == visitID) {

                System.out.println("Visit found:");
                System.out.println(current);
                return;
            }

            current = current.next;
        }

        System.out.println("Visit not found.");
    }

    // Display all visits
    public void displayVisits() {

        if (head == null) {
            System.out.println("No visit history found.");
            return;
        }

        Visit current = head;

        while (current != null) {

            System.out.println(current);

            current = current.next;
        }
    }
}