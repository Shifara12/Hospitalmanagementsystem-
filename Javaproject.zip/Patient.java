package quex;

public class Patient {
	
	int patientID;
    String name;
    int age;
    String condition;
    
    VisitHistory visitHistory;

    public Patient(int patientID, String name, int age, String condition) {
       
    	this.patientID = patientID;
        this.name = name;
        this.age = age;
        this.condition = condition;
        
        this.visitHistory = new VisitHistory();
    }

    @Override
    public String toString() {
    	
        return "ID: " + patientID +
               ", Name: " + name +
               ", Age: " + age +
               ", Condition: " + condition;
    }
}


