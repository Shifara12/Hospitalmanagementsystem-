package quex;

public class PatientQueue {
	
	private Patient[] queue;
    private int front;
    private int rear;
    private int size;

    public PatientQueue(int capacity) {
        queue = new Patient[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    // Enqueue - add patient
    public void enqueue(Patient patient) {
        if (size == queue.length) {
            System.out.println("Queue is full.");
            return;
        }

        rear++;
        queue[rear] = patient;
        size++;

        System.out.println("Patient added successfully.");
    }

    // Dequeue - remove patient
    public Patient dequeue() {
        if (size == 0) {
            System.out.println("Queue is empty. No patients waiting.");
            return null;
        }

        Patient patient = queue[front];

        for (int i = 0; i < size - 1; i++) {
            queue[i] = queue[i + 1];
        }

        rear--;
        size--;

        return patient;
    }

    // Display waiting patients
    public void displayQueue() {
        if (size == 0) {
            System.out.println("Queue is empty. No patients waiting.");
            return;
        }

        System.out.println("Patients currently waiting:");

        for (int i = 0; i < size; i++) {
            System.out.println(queue[i]);
        }
    }
}

