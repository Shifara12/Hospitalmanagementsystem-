package quex;


public class Visit {

	int visitID;
    String visitDate;
    String doctorName;
    String diagnosis;
    String treatment;

    Visit next;

    public Visit(int visitID, String visitDate, String doctorName,
                 String diagnosis, String treatment) {

        this.visitID = visitID;
        this.visitDate = visitDate;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
        this.treatment = treatment;

        this.next = null;
    }

    @Override
    public String toString() {
        return "Visit ID: " + visitID +
               ", Date: " + visitDate +
               ", Doctor: " + doctorName +
               ", Diagnosis: " + diagnosis +
               ", Treatment: " + treatment;
    }
}
	

