package quex;

public class QueueX {
	
	    private int queueArr[];
	    private int maxSize;
	    private int rear;
	    private int front;
	    private int noItem;

	    // Constructor
	    public QueueX(int s) {
	        maxSize = s;
	        queueArr = new int[maxSize];
	        rear = -1;
	        front = 0;
	        noItem = 0;
	    }

	    // Insert
	    public void insert(int j) {

	        if (isFull()) {
	            System.out.println("Queue is full");
	        } else {

	            rear++;

	            if (rear == maxSize) {
	            	rear=0;
	            }
	            queueArr[rear]=j;
	            noItem++;
}
}
	 // Remove
	    public int remove() {

	        if (isEmpty()) {
	            System.out.println("Queue is empty");
	            return -1;

	        } else {

	            int temp = queueArr[front];

	            front++;

	            if (front == maxSize) {
	                front = 0;
	            }

	            noItem--;

	            return temp;
	        }
	    }

	    // Check empty
	    public boolean isEmpty() {
	    	return noItem == 0;
	    }

//Check if queue is full
public boolean isFull() {
    return noItem == maxSize;
}
	    }