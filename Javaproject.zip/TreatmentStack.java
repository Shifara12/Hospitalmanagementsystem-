package quex;

import java.util.Stack;

public class TreatmentStack {

	Stack<String> treatmentStack = new Stack<>();

    // PUSH - add completed treatment
    public void push(String treatment) {
        treatmentStack.push(treatment);
        System.out.println("Treatment record added.");
    }

    // POP - remove most recent treatment
    public void pop() {

        if (treatmentStack.isEmpty()) {
            System.out.println("No treatment records. Stack is empty.");
        } else {
            String treatment = treatmentStack.pop();
            System.out.println("Removed treatment: " + treatment);
        }
    }

    // DISPLAY
    public void display() {

        if (treatmentStack.isEmpty()) {
            System.out.println("No treatment records. Stack is empty.");
        } else {

            System.out.println("===== Treatment History =====");

            for (int i = treatmentStack.size() - 1; i >= 0; i--) {
                System.out.println(treatmentStack.get(i));
            }
        }
    }
}

